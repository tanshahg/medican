<?php 
include "db.php";
include "include/header.php";
date_default_timezone_set("Asia/Karachi");
$sdate=date("Y-m-d",strtotime("2022-08-01"));
$edate=date("Y-m-d",strtotime("2022-08-31"));
?>
<style>
.hrow  {
	background-color: #333 !important;
	color: white;
	
}
.hrow td {
	height: 14px !important;
	font-size: 12px !important;
}
 td {
	height: 14px !important;
	font-size: 12px !important;
}

	</style>

<table class="table table-bordered">
	
		
	
	
	<tbody>

	<?php
	$aid=0;
$q="SELECT a.gname,b.name,c.id,c.name,c.mrp,c.tp,a.id FROM `companygroups`as a ,`customers` as b ,`products` as c where a.ccode=b.id and a.id=c.gcode order by c.gcode,c.name";
$s=$dbpdo->prepare($q);
$s->execute();
$cnt=0;
while($row = $s->fetch(PDO::FETCH_BOTH)){
	$gid=$row[6];
	$gname=$row[0];
	if($gid != $aid)
	{
		echo "<tr><td><h5>$gname<h5></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";
		echo "<tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";
		$aid=$gid;
		echo "<tr class='hrow'>
		<td></td><td></td>
		<td colspan=2 aling='center'>Opening</td><td style='display:none'></td>
		<td colspan=2 aling='center'>Purchase</td><td style='display:none'></td>
		<td colspan=2 aling='center'>Purchase-R</td><td style='display:none'></td>
		<td colspan=2 aling='center'>Available Stock</td><td style='display:none'></td>
		<td colspan=2 aling='center'>Sale</td><td style='display:none'></td>
		<td colspan=2 aling='center'>Sale-R</td><td style='display:none'></td>
		<td colspan=2 aling='center'>Net Sale</td><td style='display:none'></td>
		<td colspan=2 aling='center'>Closing</td><td style='display:none'></td>
		
	</tr>

		<tr class='hrow'>
		<td>Product Name</td><td>T.P</td>
		<td>Qty</td><td>Value</td>
		<td>Qty</td><td>Value</td>
		<td>Qty</td><td>Value</td>
		<td>Qty</td><td>Value</td>
		<td>Qty</td><td>Value</td>
		<td>Qty</td><td>Value</td>
		<td>Qty</td><td>Value</td>
		<td>Qty</td><td>Value</td>
		
	</tr>";
		}
$pid=$row[2];
$productname=$row[3];
$mrp=$row[4];
$tp=$row[5];
$tpv=round($mrp-($mrp*$tp/100));


$trow=$dbpdo->query("SELECT sum(quantity)+sum(bonus) as total,sum(subamount)  from stockdetail where productcode='$pid' and  stockid IN (SELECT id FROM stock where date<'$sdate')")->fetch(PDO::FETCH_NUM); 
$pqty=$trow[0];
$sprice=$trow[1];
if($pqty) {$price1=round($sprice/$pqty);} else {$price1=0;$pqty=0;}


$trow=$dbpdo->query("SELECT sum(quantity)+sum(bonus) as total  from saledetail where productcode='$pid' and saleid IN (SELECT id FROM sale where date<'$sdate')")->fetch(PDO::FETCH_NUM); 
$sqty=$trow[0];
if(!$sqty) {$spqty=0;}
$openingqty=abs($pqty-$sqty);
if($openingqty>0) $amount1=$openingqty*$price1; else $amount1=0;


$trow=$dbpdo->query("SELECT sum(quantity)+sum(bonus) as total,sum(subamount)  from stockdetail where productcode='$pid' and  stockid IN (SELECT id FROM stock where date>='$sdate' and date<='$edate')")->fetch(PDO::FETCH_NUM); 
$purchaseqty=$trow[0];
$purchaseamount=$trow[1];
if($purchaseqty) {
$price1=round($purchaseamount/$purchaseqty);
$amount2=$purchaseqty*$price1;
} 
else {
	$purchaseqty=0;
	$amount2=0;
}


$trow=$dbpdo->query("SELECT sum(quantity)+sum(bonus) as total,sum(subamount)  from stockreturndetail where productcode='$pid' and  stockid IN (SELECT id FROM stockreturn where date>='$sdate' and date<='$edate')")->fetch(PDO::FETCH_NUM); 
$preturnqty=$trow[0];
$preturnamount=$trow[1];
if($preturnqty) {
$price1=round($preturnamount/$preturnqty);
$amount3=$preturnqty*$price1;
} 
else {
	$preturnqty=0;
	$amount3=0;
}

$astock=$openingqty+$purchaseqty-$preturnqty;
$astockprice=$amount1+$amount2-$amount3;

$trow=$dbpdo->query("SELECT sum(quantity)+sum(bonus) as total,sum(subamount)  from saledetail where productcode='$pid' and  saleid IN (SELECT id FROM sale where date>='$sdate' and date<='$edate')")->fetch(PDO::FETCH_NUM); 
$saleqty=$trow[0];
$saleamount=$trow[1];
if($saleqty) {
$price1=round($saleamount/$saleqty);
$amount4=$saleqty*$price1;
} 
else {
	$saleqty=0;
	$amount4=0;
}


$trow=$dbpdo->query("SELECT sum(quantity)+sum(bonus) as total,sum(subamount)  from salereturndetail where productcode='$pid' and  saleid IN (SELECT id FROM salereturn where date>='$sdate' and date<='$edate')")->fetch(PDO::FETCH_NUM); 
$sreturnqty=$trow[0];
$sreturnamount=$trow[1];
if($sreturnqty) {
$price1=round($sreturnamount/$sreturnqty);
$amount5=$sreturnqty*$price1;
} 
else {
	$sreturnqty=0;
	$amount5=0;
}

$netsaleqty=$saleqty+$sreturnqty;
$netsaleamount=$amount4-$amount5;

$closingstock=$astock-$netsaleqty;
$closingamount=$astockprice-$netsaleamount;

echo "<tr>
	<td>$productname </td>
	<td>$tpv</td>
	<td>$openingqty</td>
	<td>$amount1</td>
	<td>$purchaseqty</td>
	<td>$amount2</td>
	<td>$preturnqty</td>
	<td>$amount3</td>
	<td>$astock</td>
	<td>$astockprice</td>
	<td>$saleqty</td>
	<td>$amount4</td>
	<td>$sreturnqty</td>
	<td>$amount5</td>
	<td>$netsaleqty</td>
	<td>$netsaleamount</td>
	<td>$closingstock</td>
	<td>$closingamount</td>


</tr>";

}
  
?>
</tbody>
</table>
