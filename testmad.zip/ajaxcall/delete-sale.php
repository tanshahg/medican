<?php
session_start();
include "../db.php";
$id=$_POST['id'];


$q1="SELECT productcode,batchno,expdate,mrp,quantity,bonus from saledetail where tableid='$id'";
  $s1=$dbpdo->prepare($q1);
$s1->execute();
while($row1 = $s1->fetch(PDO::FETCH_BOTH)) {
$productcode=$row1[0];
$batchno=$row1[1];
$expdate=$row1[2];
$mrp=$row1[3];
$qty=$row1[4];
$bonus=$row1[5];
if(empty($bonus)) $bonus=0;
$qty=$qty+$bonus;

$q="SELECT id,inhand from stockdetail where productcode='$productcode'  and batchno='$batchno' and mrp=$mrp and expdate='$expdate'";
  $s=$dbpdo->prepare($q);
$s->execute();
$row = $s->fetch(PDO::FETCH_BOTH);
$pinhand=$row[1];
$did=$row[0];
$pinhand=$pinhand+$qty;
$q="update stockdetail set inhand='$pinhand' where id='$did'";
$s=$dbpdo->prepare($q);
$s->execute();
}

$q="delete from payments where accounthead='sale' and tid='$id'";
$stmt = $dbpdo->prepare($q);
$stmt->execute();
$q="delete from saledetail where tableid='$id'";
$stmt = $dbpdo->prepare($q);
$stmt->execute();
$q="delete from sale where id='$id'";
$stmt = $dbpdo->prepare($q);
$stmt->execute();


						?>