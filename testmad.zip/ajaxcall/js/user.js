
$(function() {
$("#role-modal").on("show.bs.modal",function(event) {
	var button=$(event.relatedTarget);	
	var code=button.data("link");
	$.ajax({
     url:"ajaxcall/role.php",
     method:"POST",
     data:{code:code},
     success:function(data){

	 
		 $(".modal-body #data").html(data);
	 }
		 });
		 });
		 
		 
	 $(document).on('click', '#call', function(){
	  		  var flag="Un Check all";
		 $(".mycard input:checkbox").each(function() {
if(this.checked) {this.checked = false; flag="Check all";}
else {this.checked = true;flag="Un Check all";}
}); 
$("#call").text(flag);

	  });
	  
	  

  
  
	  
  $("#role-form").submit(function(e) {

		e.preventDefault();
		var formData = new FormData();
var other_data = $('#role-form').serializeArray();
    $.each(other_data,function(key,input){
     formData.append(input.name,input.value);
	 });
		$.ajax({
      url: 'ajaxcall/update-role.php',
      method: 'POST',
      data: formData,
      dataType:'json',  
	  processData: false,
contentType: false,
      success: function(response) {
          iziToast.success({
    title: 'success!',
    message: 'User Setting updated',
    position: 'bottomRight'
  });
		$('#role-form').trigger("reset");
		$('#role-modal').modal('toggle');
      }
    });
	
	
	 });
	 
	 fetch_data();

  function fetch_data()
  {
	  
   var dataTable = $('#user_data').DataTable({
	   
        
    	  "scrollY": 300,
        "scrollX": true,
		 "pageLength": 10,
		 "scrollX": true,
		 "stateSave": true,
		 
		 
		 
         "lengthMenu": [[10, 25, 50,100, -1], [10, 25, 50,100, "All"]],
        
               "dom": "<'row '<'col-md-12'B>><'row'<'col-md-12'>><'row'<'col-md-12'flrt>>ip",
		buttons: [
            
			 {
			 text: 'Add New User',
      action: function ( e, dt, button, config ) {
			add();
				} },   
           
        ],
    "processing" : true,
    "serverSide" : true,
	language: {
          processing: "<img src='assets/img/typing.svg'>"
      },
   

    "ajax" : {
   url:"ajaxcall/fetch-user.php",
     type:"POST",
	 
    }
   });
  }
  
  function update_data(id, column_name, value)
  {
   $.ajax({
    url:"ajaxcall/update-user.php",
    method:"POST",
    data:{id:id, column_name:column_name, value:value},
    success:function(data)
    {
		if(data!=1)
		{
     iziToast.success({
    title: 'success!',
    message: id+ ' Record is Updated with new information',
    position: 'bottomRight'
  });
	$('#user_data').DataTable().ajax.reload(null, false);
		}
     
    }
   });
   
  }

     
  $(document).on('blur', '.update', function(){
   var id = $(this).data("id");
   var column_name = $(this).data("column");
   var value = $(this).text();
   update_data(id, column_name, value);
  });
  
  
  
  $(document).on('click', '.delete', function(){
   var id = $(this).attr("id");
   swal({
    title: 'Are you sure?',
    text: 'Once deleted, you will not be able to recover this',
    icon: 'warning',
    buttons: true,
    dangerMode: true,
  })
    .then((willDelete) => {
      if (willDelete) {
    $.ajax({
    url:"ajaxcall/delete-user.php",

     method:"POST",
     data:{code:id},
     success:function(data){
		 iziToast.success({
    title: 'success!',
    message: id +' is removed from database',
    position: 'bottomRight'
  });
  
     
      
      $('#user_data').DataTable().destroy();
      fetch_data();

	  
     }
	   });
	  
	} 
	 });
	  });
  
  
  function add()
  {
	  
	  var html = '<tr>';
   html += '<td contenteditable id="data1"></td>';
   html += '<td contenteditable id="data2"></td>';
   html += '<td contenteditable id="data3">3</td>';
   html += '<td contenteditable id="data4">0</td>';
      html += '<td><button type="button" name="insert" id="insert" class="btn btn-success btn-xs">+</button>&nbsp;<button type="button" name="cancel" id="cancel" class="btn btn-warning btn-xs">X</button></td>';
   html += '</tr>';
   $('#user_data tbody').prepend(html);
    }
  
  $(document).on('click', '#cancel', function(){
	  $('#user_data').DataTable().destroy();
	fetch_data();
  });    
  
  $(document).on('click', '#insert', function(){
   var f1 = $('#data1').text();
   var f2 = $('#data2').text();
   var f3 = $('#data3').text();
   var f4 = $('#data4').text();
   
      
   if(f1 != '' && f2 != '')
   {
    $.ajax({
     url:"ajaxcall/insert-user.php",
     method:"POST",
     data:{f1: f1,f2: f2,f3: f3,f4:f4},
     success:function(data)
      {
      iziToast.success({
    title: 'success!',
    message: f1+' added as new user',
    position: 'bottomRight'
  });
  
      $('#user_data').DataTable().destroy();
      fetch_data();
     }
    });
    
   }
   else
   {
	   swal('Blank', 'Username and Password required!', 'error');
    
   }
  });






});
