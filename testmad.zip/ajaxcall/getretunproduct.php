<?php
include "../db.php";
$output="";
$output1="";
$output2="";
$output3="";
$pid=$_POST['pid'];

$q="select distinct mrp from stockdetail where productcode='$pid' and inhand>0";
$s=$dbpdo->prepare($q);
$s->execute();
$mrp=0;
while($row = $s->fetch(PDO::FETCH_BOTH)){
	if($mrp==0) $mrp=$row[0];
$output1.="<option value='$row[0]'>$row[0]</option>";
}


$q="select distinct batchno from stockdetail where productcode=$pid and mrp='$mrp'  and inhand>0";
$s=$dbpdo->prepare($q);
$btno=0;
$s->execute();
while($row = $s->fetch(PDO::FETCH_BOTH)){
	if($btno==0) $btno=$row[0];
$output2.="<option value='$row[0]'>$row[0]</option>";
}

$q="select distinct expdate from stockdetail where productcode='$pid' and mrp='$mrp' and batchno='$btno' and inhand>0";
$s=$dbpdo->prepare($q);
$s->execute();
$expdate=0;
while($row = $s->fetch(PDO::FETCH_BOTH)){
	if($expdate==0) $expdate=$row[0];
$output3.="<option value='$row[0]'>$row[0]</option>";
}


$q="select inhand from stockdetail where productcode=$pid and batchno='$btno' and expdate='$expdate' and mrp='$mrp'";
$s=$dbpdo->prepare($q);
$s->execute();
$row = $s->fetch(PDO::FETCH_BOTH);
$qty=$row[0];

echo json_encode(array("a"=>$output1,"b"=>$output2,"c"=>$output3,"d"=>$qty));

						?>