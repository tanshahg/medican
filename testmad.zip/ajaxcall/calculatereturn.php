<?php
include "../db.php";
$pid=$_POST['pid'];
$batch=$_POST['batch'];
$mrp=$_POST['mrp'];
$expdate=$_POST['expdate'];
$pqty=$_POST['pqty'];
$table=$_POST['table'];


$q="select quantity,inhand,bonus,tp,dis1,gst,extra,netrate from stockdetail where productcode=$pid and batchno='$batch' and expdate='$expdate' and mrp='$mrp'";
$s=$dbpdo->prepare($q);
$s->execute();
$row = $s->fetch(PDO::FETCH_BOTH);
$qty=$row[0];
$inhand=$pqty;
$bonus=$row[2];
$tp=$row[3];
$dis=$row[4];
$gst=$row[5];
$extra=$row[6];
$netrate=$row[7];
$unitdiscount=round($dis/($qty+$bonus),2);

$unitgst=round($gst/($qty+$bonus),2);
$unitextra=round($extra/($qty+$bonus),2);
if(empty($bonus)) $bonus=0;
$totaltp=$row[3]*($inhand-$bonus);
$totaldiscount=round($unitdiscount*$inhand,2);
$totalgst=round($unitgst*$inhand,2);
$totalextra=round($unitextra*$inhand,2);
$subamount=round($totaltp-$totaldiscount,2);
$netamount=round($subamount+$totalgst+$totalextra,2);
$subamount=round($netamount-$totaldiscount,2);
echo json_encode(array("a"=>$tp,"b"=>$totaldiscount,"c"=>$netrate,"d"=>$inhand,"e"=>$bonus,"f"=>$totalgst,"g"=>$totalextra,"h"=>$subamount,"i"=>$netamount));

						?>