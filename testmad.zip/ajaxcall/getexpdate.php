<?php
include "../db.php";

$pid=$_POST['pid'];
$btno=$_POST['btno'];
$output="";

$q="select distinct expdate from stockdetail where productcode='$pid' and batchno='$btno'";
$s=$dbpdo->prepare($q);
$s->execute();
while($row = $s->fetch(PDO::FETCH_BOTH)){
$output.="<option value='$row[0]'>$row[0]</option>";
}

echo $output;



						?>