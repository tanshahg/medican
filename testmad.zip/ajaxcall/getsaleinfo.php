<?php
include "../db.php";
$pid=$_POST['pid'];
$pcode=$_POST['pcode'];
$btno=$_POST['btno'];
$expdate=$_POST['expdate'];
$q="select * from  stockdetail where productcode='$pid' and packingcode='$pcode' and batchno='$btno' and expdate='$expdate';
";
$s=$dbpdo->prepare($q);
$s->execute();
$n=1;
$mrp="";
while($row = $s->fetch(PDO::FETCH_BOTH)){
$mrp="<option value='$row[10]'>$row[10]</option>";
if($n==1)
{
$tp=$row[10]-$row[10]*$row[11]/100;
$dis=0;
$netrate=$row[14];
}
}


echo json_encode(array("a"=>$mrp,"b"=>$tp,"c"=>$dis,"d"=>$netrate));

						?>