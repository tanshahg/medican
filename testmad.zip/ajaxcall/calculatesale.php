<?php
include "../db.php";
$pid=$_POST['pid'];
$pcode=$_POST['pcode'];
$btno=$_POST['btno'];
$expdate=$_POST['expdate'];
$mrp=$_POST['mrp'];
$tpamount=$_POST['tp'];
$dis1=$_POST['dis'];
$netrate=$_POST['nrate'];
$qty=$_POST['qty'];
$gst=$_POST['gst'];
$extra=$_POST['extra'];
$bonus=$_POST['bonus'];
$rr=$_POST['rr'];
$subtotal=0;
$nettotal=0;

    if($qty)
    {
  $row=$dbpdo->query("SELECT sum(inhand) from stockdetail where productcode='$pid'  and batchno='$btno' and mrp='$mrp' ")->fetch(PDO::FETCH_NUM);	
  
$inahnd=$row[0];
if(!$rr)
if($inahnd<$qty)
{
echo json_encode(array("a"=>0,"b"=>0));	
exit;
}

$gst1=0;
$extra1=0;
$subtotal=0;
$nettotal=0;
$bgst=0;
$bextra=0;
$totalgst=0;
$totalextra=0;
$damount=0;

if($netrate)
{
$subtotal=$netrate*$qty;
$nettotal=$netrate*$qty;
}
else
{
	
	$amount1=$tpamount*$qty;
	
	

	
   $dis=0;
        if($dis1>0) $dis=($amount1*$dis1)/100;
        
        $amount1=$amount1-$dis;

    
    if(!empty($gst))
    {
    	
        $gst1=($amount1*$gst)/100;
       
	if($bonus)
	{
		$bonusamount=$tpamount*$bonus;
		$bgst=($bonusamount*$gst)/100;

	}

        }
    if(!empty($extra))
    {
    	
        $extra1=($amount1*$extra)/100;
        

        if($bonus)
	{
		$extraamount=$tpamount*$bonus;
		$bextra=($extraamount*$extra)/100;

	}

        }

        $amount1=$amount1+$gst1+$extra1+$bgst+$bextra;

	$subtotal=round($amount1-$dis,2);
	$nettotal=round($amount1,2);

	$totalgst=round($gst1+$bgst,2);
	$totalextra=round($extra1+$bextra,2);
	$damount=round($dis,2);
	

	
}
}

echo json_encode(array("a"=>$subtotal,"b"=>$nettotal,"c"=>$totalgst,"d"=>$totalextra,"e"=>$dis));

						?>