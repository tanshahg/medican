<?php 
include "secure.php";
include "include/header.php";
date_default_timezone_set('Asia/Karachi');
?>
<style>
.ss {
	overflow-y: auto;
	max-height:320px;
}
</style>
</head>

<body >

  <div class="loader"></div>
 <?php include "include/menu.php"; ?>
      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <h1> Welcome <?php $currentuser ?></h1>
          </div></div>
          
		  
  <?php include "include/footer.php";?>


  